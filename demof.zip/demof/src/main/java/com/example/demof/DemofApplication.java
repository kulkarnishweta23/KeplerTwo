package com.example.demof;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemofApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemofApplication.class, args);
	}

}
